# -*- coding: utf-8 -*-

from . import res_config_settings
from . import ir_ui_view
from . import base_language_install
from . import ir_module_module
from . import web_environment_ribbon_backend
# from . import ir_ui_menu
